<template>
  <div>
    Forgot Password
  </div>
</template>

<script>
export default {};
</script>
